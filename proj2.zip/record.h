/* @(#)record.h	1.2 10/18/17 */
/*****************************************************************
//
//  NAME:        Clifton Miyamoto
//  //
//  //  HOMEWORK:    3
//  //
//  //  CLASS:       ICS 212
//  //
//  //  INSTRUCTOR:  Ravi Narayan
//  //
//  //  DATE:        September 17, 2017           
//  //
//  //  FILE:        record.h
//  //
//  //  DESCRIPTION:
//  //   This file contains the structure record for homework 3
//  //
//  ****************************************************************/

#ifndef record_h
#define record_h

struct record
{
    int accountno;
    char name[25];
    char address[80];
    struct record *next;
};

#endif
