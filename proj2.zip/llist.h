#include "record.h"

class llist
{
    private:
        record * start;
        char filename[16];
        int readfile();
        int writefile();
        record * reverse(record *);
        void cleanup();

    public:
	llist();
	llist(char[]);
	~llist();
	int addRecord(int, char[], char[]);
	int printRecord(int);
	int modifyRecord(int, char[]);
	// replace printAll() with the << operator
	int deleteRecord(int);
	void reverse();
	friend std::ostream &operator <<(std::ostream &output, const llist &list);
};
