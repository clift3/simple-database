/* %W% %G%*/
/*****************************************************************
//
//  NAME:        Clifton Miyamoto
//  //
//  //  HOMEWORK:    Project 2
//  //
//  //  CLASS:       ICS 212
//  //
//  //  INSTRUCTOR:  Ravi Narayan
//  //
//  //  DATE:        November 18, 2017           
//  //
//  //  FILE:        proj2ui.cpp
//  //
//  //  DESCRIPTION:
//  //   This file contains the main function and menu for Project 2
//  //   as well as the getaddress function
//  //
//  ****************************************************************/

#include <iostream>
#include <stdlib.h>
#include <string.h>
#include "record.h"
#include "llist.h"


void getaddress (char [], int);
void getaccountno(int&);

/*****************************************************************
//
//  Function name: main
//  //
//  //  DESCRIPTION:   The main function that includes the menu for 
//  //                     database 
//  //               
//  //  Parameters:    argc (int) : the number of arguments passed
//  //                 argv (char *[]) : An array of char pointers to the
//  //                     arguments passed
//  //
//  //  Return values:  0 : success
//  //                  1 : invalid argument
//  ****************************************************************/

int main(int argc, char *argv[])
{
    
    int activeMenu = 1;
    int menuInput, accountno, functionstatus, validinput;
    char name[25], address[80];
    char filename[] = "database.txt";
    int addresslen = 80;
    functionstatus = 0;
    
    llist list = llist(filename);

    do
    {
        std::cout << "Enter the number of the option to execute\n";
        std::cout << "1. Add a new record\n";
        std::cout << "2. Modify a record in the database using the accountno as the key\n";
        std::cout << "3. Print information about a record using the accountno as the key\n";
        std::cout << "4. Print all information in the database\n";
        std::cout << "5. Delete an existing record from the database using the accountno as a key\n";
        std::cout << "6. Reverse the order of the database\n";
        std::cout << "0. Quit program\n";
        
        menuInput = validinput = -1; 
        while(validinput < 0)
        { 
            std::cin >> menuInput;
            if(std::cin.fail())
            {
                std::cout << "Please enter a valid menu option\n\n";
                std::cin.clear();
                std::cin.ignore(100, '\n');
            }
            else
            {
                validinput = 1;
            }
        }
        switch(menuInput)
        {
            case 0 :
                activeMenu = 0;
                break;
            case 1 :
                getaccountno(accountno);
                std::cout << "Enter the name of the account\n";
                std::cin.getline(name, 24);
                getaddress(address, addresslen);
                functionstatus = list.addRecord(accountno, name, address);
                if(functionstatus == -1)
                {
                    std::cout << "Record already exists!\n\n";
                }
                else
                {
                    std::cout << "Record successfully added.\n\n";
                }
                break;
            case 2: 
                    getaccountno(accountno);
                    getaddress(address, addresslen);
                    functionstatus = list.modifyRecord(accountno, address);
                    if(functionstatus == -1)
                    {
                        std::cout << "Record does not exist in database\n\n";
                    }
                    if(functionstatus == -2)
                    {
                        std::cout << "The database is empty\n\n";
                    }
                    if(functionstatus == 0)
                    {
                        std::cout << "Record " << accountno << " modified\n\n";
                    }
                break;
            case 3 :      
                    getaccountno(accountno);
                    functionstatus = list.printRecord(accountno);
                    if(functionstatus == -1)
                    {
                        std::cout << "Record does not exist in the database\n\n";
                    }
                    if(functionstatus == -2)
                    {
                        std::cout << "The database is empty\n\n";
                    }
                break;
            case 4 :
                std::cout << list;
                break;
            case 5 :
                    getaccountno(accountno);
                    functionstatus = list.deleteRecord(accountno);
                    if(functionstatus == -1)
                    {
                        std::cout << "Record does not exist in database\n\n";
                    }
                    if(functionstatus == -2)
                    {
                        std::cout << "The database is empty\n\n";
                    }
                    if(functionstatus == -0)
                    {
                        std::cout << "Record " << accountno << " deleted\n\n";
                    }
                break;
            case 6 :
		    list.reverse();
                    std::cout << "The database has been reversed.\n\n";
            default:
                std::cout << "Please enter a valid menu option\n\n";
                std::cin.ignore(100, '\n');
        }
    } while(activeMenu == 1);
    return 0;
}

/*****************************************************************
//
//  Function name: getaddress   
//  //
//  //  DESCRIPTION:   A function that prompts the user and gets an address
//  //                     of any number of lines. Ends when the user enters only "\n"
//  //               
//  //  Parameters:    address (char []) : the char array the address is stored in
//  //                 addresslen (int) : the length of the char array, address
//  //
//  ****************************************************************/

void getaddress (char address[], int addresslen)
{
    int loop = 1;
    char temp[80];

    #ifdef debug
        std::cout << "DEBUG*** function getaddress: char address = " << address << " int addresslen = " << addresslen << "\n";
    #endif

    std::cout << "Enter the address. Enter nothing to end input.\n";
    std::cin.getline(address, addresslen);
    address[strlen(address) + 1] = '\0';
    address[strlen(address)] = '\n';
    while(loop == 1)
    {
        std::cin.getline(temp, addresslen);
        if(strlen(temp) == 0)
        {
            loop = 0;
        }
        else
        {
            temp[strlen(temp)+1] = '\0';
            temp[strlen(temp)] = '\n';
            if(strlen(temp) + strlen(address) > (unsigned)addresslen)
            {
                loop = 0;
            }
            else
            {
                strcat(address, temp);
            }
        }
    }
}

/*****************************************************************
//
//  Function name: getaccountno   
//  //
//  //  DESCRIPTION:   A function that prompts the user and gets the account number 
//  //               
//  //  Parameters:    account (& int ) : integer that stores the account number
//  //
//  ****************************************************************/

void getaccountno (int &account)
{
    int validinput = 0;
    #ifdef debug
        std::cout << "DEBUG*** function getaccountno: int account = " << account << "\n";
    #endif
    std::cout << "Enter the account number\n";
    while(validinput == 0)
    {
        std::cin >> account;
        if(!std::cin.fail())
        {
            validinput = 1;
        }
        else
        {
            std::cin.clear();
            std::cin.ignore(100, '\n');
            std::cout << "Enter a valid account number\n";
        }
    }
}
