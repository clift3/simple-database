/* %W%  %G% */
/*****************************************************************
//
//  NAME:        Clifton Miyamoto
//  //
//  //  HOMEWORK:    Project 2
//  //
//  //  CLASS:       ICS 212
//  //
//  //  INSTRUCTOR:  Ravi Narayan
//  //
//  //  DATE:        November 18, 2017           
//  //
//  //  FILE:        llist.cpp
//  //
//  //  DESCRIPTION:
//  //   This file contains the class functions for llist for Project 2
//  //
//  ****************************************************************/

#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <string.h>
#include "llist.h"
#include "record.h"

llist::llist()
{
    this->start = NULL;
    char name[] = "database.txt";
    strcpy(filename, name);
    readfile();
}

llist::llist(char fname[])
{
    int i;
    this->start = NULL;
    for(i = 0; i < 16; i++)
    {
        this->filename[i] = fname[i];
    }
    readfile();
}

llist::~llist()
{
    writefile();
    cleanup();
}

/*****************************************************************
//  Function name: readfile
//
//  DESCRIPTION:   Reads accounts from a file and stores them in a array
//                     of records.
//
//  Return values:      0  : The file was successfully read
//  			-1 : no file name char filename[] exists
//                  
//
****************************************************************/

int llist::readfile()
{
    int returnvalue, loop, accnum, nofile;
    char temp[80];
    std::string str;
    struct record *temp2;
    struct record *temp3;
    std::ifstream file;
    loop = returnvalue = 0;
    nofile = 1;

    #ifdef debug
        std::cout << "DEBUG*** function readfile: char filename = " << filename << "\n";
    #endif
    file.open(this->filename);
    if(!file)
    {
        returnvalue = -1;
        nofile = 0;
    }
    if(nofile != 0)
    {
        temp2 = temp3 = this->start;
        while(!file.eof())
        {
            file >> accnum;
            if(file.eof())
            {

            }
            else
            {
            std::getline(file, str);
            if(start != NULL)
            {  
                temp2 = start;  
                while(temp2 != NULL)
                {
                    if((*temp2).accountno == accnum)
                    {
                        loop = -1;
                    }
                    temp3 = temp2;
                    temp2 = (*temp2).next;
                }
            }
            if(loop == 0)
            {
                temp2 = (record *)malloc(sizeof(struct record));
		(*temp2).next = NULL;
                (*temp2).address[0] = '\0';
                if(temp3 == NULL)
                {
                    start = temp2;
                }
                else
                {
                    (*temp3).next = temp2;
                }

                (*temp2).accountno = accnum;
                file.get(temp, 25, '\n');
	        strcpy((*temp2).name, temp);
                file.getline(temp, 50);
                loop = 1;
                
                while(loop == 1)
                {   
			std::getline(file, str);                   
                    if(str.length() == 0)
                    {
                        loop = 0;
                        temp2->address[strlen(temp2->address)+1] = '\0';
                        temp2->address[strlen(temp2->address)] = '\n';
                    }
                    else
                    {
                        strcat((*temp2).address, str.c_str());
                        temp2->address[strlen(temp2->address)+1] = '\0';
                        temp2->address[strlen(temp2->address)] = '\n';
                    }
	        }
                temp3 = temp2;
            }
            else
            {
                std::getline(file, str);                
                while(loop == -1)
                {   
                    std::getline(file, str);
                    if(str.length() == 0)
                    {
                        loop = 0;
                    }
                }
            }
            }
        } 
        file.close();
        returnvalue = 0;
    }

    return returnvalue;
}

/*****************************************************************
//  Function name: writefile
//
//  DESCRIPTION:   Writes an array of records to a file
//
//  Return values:  0 : the writing was successful
//		    -1: the writing was unsuccessful
//
****************************************************************/
int llist::writefile()
{
    int returnvalue;
    struct record *temp;
    temp = start;
    std::ofstream file(filename);
    #ifdef debug
        std::cout << "DEBUG*** function writefile: char filename = " << filename << "\n";
    #endif

    if(!file.is_open())
    {
        returnvalue = -1;
    }
    else
    {
        while(temp != NULL)
        {
            file << temp->accountno << "\n" << temp->name << "\n" << temp->address << "\n";
            temp = (*temp).next;
        }
        file.close();
        returnvalue = 0;
    }
    return returnvalue;
}

/*****************************************************************
//
//  Function name: addRecord   
//  //
//  //  DESCRIPTION:   Adds a record to the database 
//  //
//  //  Parameters:    accountno (int) : the account number to be added
//  //                 name (char []) : the name of the account
//  //                 address (char []) : the address of the account
//  //
//  //  Return values:  0 : success 
//  //
//  ****************************************************************/

int llist::addRecord (int accountno, char name[ ], char address[ ])
{
    int returnvalue;
    struct record *temp;
    struct record *temp2;
    returnvalue = 0;
    temp2 = NULL;
    temp = start;

    #ifdef debug
        std::cout << "DEBUG*** function addrecord: int accountno = " << accountno << " char name = " << name << " char address = " << address << "\n"; 
    #endif

    while(temp != NULL && returnvalue != -1)
    {
        if((*temp).accountno == accountno)
	    returnvalue = -1;
        if((*temp).next == NULL)
            temp2 = temp;
        temp = (*temp).next;
    }
    if(returnvalue != -1)
    {
        temp = (record *)malloc(sizeof(struct record));
        (*temp).accountno = accountno;
        strcpy((*temp).name, name);
        strcpy((*temp).address, address);
        (*temp).next = NULL;
        if(temp2 != NULL)
        {
            (*temp2).next = temp;
        }
	else
	{
	    start = temp;
	}    
    }
    return returnvalue;
}

/*****************************************************************
//
//  Function name: printRecord   
//  //
//  //  DESCRIPTION:   A function that prints the specified record 
//  //               
//  //  Parameters:    accountno (int) : the account number of the record to be printed
//  //
//  //  Return values:  0 : success
//  //			-1: the record with the specified accountno does not exist
//  //			-2: the list is empty
//  //
//  ****************************************************************/
int llist::printRecord (int accountno)
{
    int returnvalue;
    struct record *temp;
    struct record *temp2;
    temp = temp2 = this->start;
    returnvalue = 1;

    #ifdef debug
        std::cout << "DEBUG*** function printRecord: int accountno = " << accountno << "\n";
    #endif

     if(start == NULL)
    {
        returnvalue = -2;
    }
    else if((*start).accountno == accountno)
    {
        std::cout << "Account Number: " << (*temp).accountno << "\n" << "Name: " << (*temp).name << "\n" << "Address: " << (*temp).address << "\n";
        returnvalue = 0;
    }
    else
    {
        while(returnvalue == 1)
        {
            temp = (*temp).next;
            if( temp == NULL)
            {
                returnvalue = -1;
            }
            else if((*temp).accountno == accountno)
            {
                std::cout << "Account Number: " << (*temp).accountno << "\n" << "Name: " << (*temp).name << "\n" << "Address: " << (*temp).address << "\n";
                returnvalue = 0;
            }
        }
    }
    return returnvalue;
 
}
/*****************************************************************
//
//  Function name: modifyRecord   
//  //
//  //  DESCRIPTION: A function that modifies a specific record  
//  //
//  //  Parameters:    accountno (int) : the account number of the record being modified
//  //                 address (char []) : the address of the record being modified
//  //
//  //  Return values:  0 : success
//  //			-1: the specified record does not exist
//  //			-2: the list is empty
//  //
//  ****************************************************************/
int llist::modifyRecord (int accountno, char address[ ])
{
    int returnvalue;
    struct record *temp;
    temp = this->start;
    returnvalue = 1;

    #ifdef debug
        std::cout << "DEBUG*** function modifyRecord: int accountno = " << accountno << " char address = " << address << "\n";
    #endif

    if(start == NULL)
    {
        returnvalue = -2;
    }
    else if((*start).accountno == accountno)
    {
        strcpy((*start).address, address);
        returnvalue = 0;
    }
    else
    {
        while(returnvalue == 1)
        {
            temp = (*temp).next;
            if( temp == NULL)
            {
                returnvalue = -1;
            }
            else if((*temp).accountno == accountno)
            {
                strcpy((*temp).address, address);
                returnvalue = 0;
            }
        }
    }
    return returnvalue;
}

/*****************************************************************
//
//  Function name: operator <<   
//  //
//  //  DESCRIPTION:   function that overloads the << operator  
//  //
//  //  Parameters:    output (ostream) : the ostream to send to
//  //                 list (llist) : the list containing the records
//  //
//  //  Return values:  0 : success
//  //			-1: the specified record does not exist
//  //			-2: the list is empty
//  //
//  ****************************************************************/

std::ostream &operator <<(std::ostream &output, const llist &list)
{
    record * temp;
    temp = list.start;
  
    #ifdef debug
        std::cout << "DEBUG*** function printAllRecords\n";
    #endif
    
    if(temp == NULL)
    {
        output << "The database is empty!\n\n";
    }
    while(temp != NULL)
    {
        output << "Account Number: " << (*temp).accountno << "\n" << "Name: " << (*temp).name << "\n" << "Address: " << (*temp).address << "\n";
        temp = (*temp).next;
    }
    output << "\n";
    return output;
}
/*****************************************************************
//
//  Function name: cleanup   
//  //
//  //  DESCRIPTION:  A function that cleans (frees) all the records in the database 
//  //                 
//  ****************************************************************/
void llist::cleanup()
{
    struct record *temp;
    struct record *temp2;
    temp = start;
  
    #ifdef debug
        std::cout << "DEBUG*** function cleanup\n";
    #endif
    
    while(temp != NULL)
    {
        temp2 = temp->next;
        free(temp);
        temp = temp2;
    }
}
/*****************************************************************
//
//  Function name: deleteRecord   
//  //
//  //  DESCRIPTION:   A function that deletes the record of the given account number 
//  //
//  //  Parameters:    accountno (int): the number of the account to be deleted
//  //
//  //  Return values:  0 : success
//  //			-1: the specified record does not exist
//  //			-2: the list is empty
//  //
//  ****************************************************************/
int llist::deleteRecord(int accountno)
{
    int returnvalue;
    struct record *temp;
    struct record *temp2;
    temp = temp2 = this->start;
    returnvalue = 1;

    #ifdef debug
        std::cout << "DEBUG*** function deleteRecord: int accountno = " << accountno << "\n";
    #endif

    if(start == NULL)
    {
        returnvalue = -2;
    }
    else if((*start).accountno == accountno)
    {
        temp = (*start).next;
        free(start);
        start = temp;
        returnvalue = 0;
    }
    else
    {
        while(returnvalue == 1)
        {
            temp = (*temp).next;
            if( temp == NULL)
            {
                returnvalue = -1;
            }
            else if((*temp).accountno == accountno)
            {
                (*temp2).next = (*temp).next;
                free(temp);
                returnvalue = 0;
            }
            else
            {
                temp2 = temp;
            }
        }
    }
    return returnvalue;

}

/*****************************************************************
//
//  Function name: reverse   
//  //
//  //  DESCRIPTION:   A function that reverses the order of the linked list 
//  //
//  //  Parameters:    point (record *) : the record pointer to start at
//  //
//  //  Return values:  record *: The end of the new linked list
//  //
//  ****************************************************************/

record * llist::reverse(record * point)
{
    if(point == NULL)
    {
    }
    else if(point->next == NULL)
    {
        this->start = point;
    }
    else
    {
        reverse(point->next);
        point->next->next = point;
        point->next = NULL;
    }
    return point;
}

/*****************************************************************
//
//  Function name: reverse   
//  //
//  //  DESCRIPTION:   A function that reverses the order of the linked list by calling reverse(record *) 
//  //
//  ****************************************************************/

void llist::reverse()
{
    reverse(this->start);
}
